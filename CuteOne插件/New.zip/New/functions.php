<?php
/*
 * Function to generate pronounceable word 
 */
function generateRandomWord() {
    $c  = 'bcdfghjklmnprstvwz'; //consonants except hard to speak ones
    $v  = 'aeiou';              //vowels
    $a  = $c.$v;                //both
    $pw = '';
    for($j=0;$j < 2; $j++){
        $pw .= $c[rand(0, strlen($c)-1)];
        $pw .= $v[rand(0, strlen($v)-1)];
        $pw .= $a[rand(0, strlen($a)-1)];
    }
    return $pw;
}
/*
 * Return a single random domain from the list of the domain defined in config.php file
 */
function generateRandomDomain($domainList) {
    $count = count($domainList);
    $selectedDomain = rand(1,$count) - 1;
    return $domainList[$selectedDomain];
}
/*
 * Function to recursively delete all files and folders
 */
function rrmdir($dir) {
    if (is_dir($dir)) {
        $objects = scandir($dir);
        foreach ($objects as $object) {
            if ($object != "." && $object != "..") {
                if (filetype($dir."/".$object) == "dir") 
                    rrmdir($dir."/".$object); 
                else unlink   ($dir."/".$object);
            }
        }
        reset($objects);
        rmdir($dir);
    }
}
?>