<?php
$option = array(
"deleteDays"=>"3",
"refreshRate"=>"5",
"ads"=>"",
"ssl"=>"yes",
"logs"=>"no",
"encode"=>"yes",
"pushNotifications"=>"yes",
"timezone"=>"Asia/Kolkata",
"defaultlanguage"=>"en",
"linksIcon"=>array("fa-address-book","fa-shopping-cart","fa-superpowers"),
"linksTitle"=>array("Home","Purchase","Developer"),
"linksValue"=>array("http://envato.stackants.com/tmail/demo/modern","https://codecanyon.net/item/tmail-multi-domain-temporary-email-system/20177819","https://codecanyon.net/user/harshitpeer"),
"layout"=>"full",
);
?>