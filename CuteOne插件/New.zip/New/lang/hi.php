<?php

$lang['setid'] = "ईमेल आईडी सेट करें	";
$lang['create'] = "सर्जन करना";
$lang['or'] = "या";
$lang['generaterandom'] = "बिना सोचे समझे";
$lang['switch'] = "ईमेल आईडी स्विच करें";
$lang['getnew'] = "नई आईडी बनाएं";
$lang['loading'] = "लोड हो रहा है";
$lang['yourcurrent'] = "आपकी वर्तमान ईमेल आईडी";
$lang['search'] = "ईमेल के लिए खोजें	";
$lang['today'] = "आज";
$lang['yesterday'] = "बिता कल";
$lang['menu'] = "मुख्य मेनू";
$lang['youremailshere'] = "आपके ईमेल यहां प्रदर्शित होंगे";
$lang['noselected'] = "कोई ईमेल नहीं चुना गया";
$lang['clearlist'] = "स्पष्ट सूची";
$lang['reloading'] = "पुन: लोड";
$lang['seconds'] = "सेकंड में";

