<?php

$lang['setid'] = "Définir l'ID de messagerie";
$lang['create'] = "Créer";
$lang['or'] = "OU";
$lang['generaterandom'] = "au hasard";
$lang['switch'] = "Changer le numéro de messagerie";
$lang['getnew'] = "Créer un nouvel identifiant";
$lang['loading'] = "Chargement";
$lang['yourcurrent'] = "Votre identifiant de messagerie actuel";
$lang['search'] = "Rechercher EMail";
$lang['today'] = "Aujourd'hui";
$lang['yesterday'] = "Hier";
$lang['menu'] = "Menu principal";
$lang['youremailshere'] = "Vos e-mails s'afficheront ici";
$lang['noselected'] = "Aucun email sélectionné";
$lang['clearlist'] = "Effacer la liste";
$lang['reloading'] = "Rechargement en";
$lang['seconds'] = "secondes";

