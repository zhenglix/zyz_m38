<?php

$lang['setid'] = "Set EMail ID";
$lang['create'] = "Create";
$lang['or'] = "OR";
$lang['generaterandom'] = "Random";
$lang['switch'] = "Switch EMail ID";
$lang['getnew'] = "Get New EMail ID";
$lang['loading'] = "Loading";
$lang['yourcurrent'] = "Your current EMail ID";
$lang['search'] = "Search for EMail";
$lang['today'] = "Today";
$lang['yesterday'] = "Yesterday";
$lang['menu'] = "Main Menu";
$lang['youremailshere'] = "Your Emails will display here";
$lang['noselected'] = "No Email Selected";
$lang['clearlist'] = "Clear List";
$lang['reloading'] = "Reloading in";
$lang['seconds'] = "seconds";
