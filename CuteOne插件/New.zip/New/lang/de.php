<?php

$lang['setid']="Legen Sie die E-Mail-ID fest";
$lang['create']="Erstellen";
$lang['or']="ODER";
$lang['generaterandom']="Zufällig";
$lang['switch']="E-Mail-ID wechseln";
$lang['getnew']="Erhalte eine neue E-Mail-ID";
$lang['loading']="Wird geladen";
$lang['yourcurrent']="Ihre aktuelle E-Mail-ID";
$lang['search']="Suche nach E-Mail";
$lang['today']="Heute";
$lang['yesterday']="Gestern";
$lang['menu']="Hauptmenü";
$lang['youremailshere']="Ihre E-Mails werden hier angezeigt";
$lang['noselected']="Keine E-Mail ausgewählt";
$lang['clearlist'] = "Liste leeren";
$lang['reloading'] = "Nachladen in";
$lang['seconds'] = "sekunden";