<?php

$lang['setid'] = "Establecer ID de correo electrónico";
$lang['create'] = "Crear";
$lang['or'] = "O";
$lang['generaterandom'] = "Aleatorio";
$lang['switch'] = "Cambiar la identificación de EMail";
$lang['getnew'] = "Crear nueva ID";
$lang['loading'] = "Cargando";
$lang['yourcurrent'] = "Su identificación actual de EMail";
$lang['search'] = "Búsqueda de correo electrónico";
$lang['today'] = "Hoy";
$lang['yesterday'] = "Ayer";
$lang['menu'] = "Menú principal";
$lang['youremailshere'] = "Sus correos electrónicos se mostrarán aquí";
$lang['noselected'] = "Sin correo electrónico seleccionado";
$lang['youremailshere'] = "Sus correos electrónicos se mostrarán aquí";
$lang['noselected'] = "Sin correo electrónico seleccionado";
$lang['clearlist'] = "Limpiar lista";
$lang['reloading'] = "Recarga en";
$lang['seconds'] = "segundos";

