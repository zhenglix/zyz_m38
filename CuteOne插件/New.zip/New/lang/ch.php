<?php

$lang['setid'] = "设置电子邮件ID";
$lang['create'] = "创建";
$lang['or'] = "要么";
$lang['generaterandom'] = "随机";
$lang['switch'] = "切换电子邮件ID";
$lang['getnew'] = "创建新ID";
$lang['loading'] = "载入中";
$lang['yourcurrent'] = "您当前的电子邮件ID";
$lang['search'] = "搜索电子邮件";
$lang['today'] = "今天";
$lang['yesterday'] = "昨天";
$lang['menu'] = "主菜单";
$lang['youremailshere'] = "您的电子邮件将显示在此处";
$lang['noselected'] = "没有选择电子邮件";
$lang['clearlist'] = "清晰的列表";
$lang['reloading'] = "重新加载";
$lang['seconds'] = "秒";

