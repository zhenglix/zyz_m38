<?php

$lang['setid'] = "Ustaw identyfikator e-mail";
$lang['create'] = "Stwórz";
$lang['or'] = "LUB";
$lang['generaterandom'] = "Losowy";
$lang['switch'] = "Zmień identyfikator e-mail";
$lang['getnew'] = "Utwórz nowy identyfikator";
$lang['loading'] = "Ładuję";
$lang['yourcurrent'] = "Twój obecny identyfikator e-mail";
$lang['search'] = "Wyszukaj wiadomość e-mail";
$lang['today'] = "Dzisiaj";
$lang['yesterday'] = "Wczoraj";
$lang['menu'] = "Menu główne";
$lang['youremailshere'] = "Twoje wiadomości e-mail zostaną wyświetlone tutaj";
$lang['noselected'] = "Nie wybrano adresu e-mail";
$lang['clearlist'] = "Czysta lista";
$lang['reloading'] = "Ponowne ładowanie";
$lang['seconds'] = "sekundy";
