<?php

$lang['setid'] = "Установить идентификатор EMail";
$lang['create'] = "Создайте";
$lang['or'] = "ИЛИ";
$lang['generaterandom'] = "случайный";
$lang['switch'] = "Переключить идентификатор EMail";
$lang['getnew'] = "Создать новый идентификатор";
$lang['loading'] = "загрузка";
$lang['yourcurrent'] = "Текущий идентификатор EMail";
$lang['search'] = "Поиск EMail";
$lang['today'] = "Cегодня";
$lang['yesterday'] = "Вчера";
$lang['menu'] = "Главное меню";
$lang['youremailshere'] = "Ваши электронные письма будут отображаться здесь";
$lang['noselected'] = "Не выбрано Email";
$lang['clearlist'] = "Очистить список";
$lang['reloading'] = "Перезагрузка в";
$lang['seconds'] = "секунд";
