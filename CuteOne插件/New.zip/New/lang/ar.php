<?php

$lang['setid'] = "تعيين معرف البريد الإلكتروني	";
$lang['create'] = "خلق	";
$lang['or'] = "أو	";
$lang['generaterandom'] = "عشوائية	";
$lang['switch'] = "تبديل معرف البريد الإلكتروني	";
$lang['getnew'] = "إنشاء معرف جديد	";
$lang['loading'] = "جار التحميل	";
$lang['yourcurrent'] = "معرف البريد الإلكتروني الحالي الخاص بك	";
$lang['search'] = "البحث عن البريد الإلكتروني	";
$lang['today'] = "اليوم	";
$lang['yesterday'] = "في الامس	";
$lang['menu'] = "القائمة الرئيسية	";
$lang['youremailshere'] = "سيتم عرض رسائل البريد الإلكتروني الخاصة بك هنا	";
$lang['noselected'] = "لم يتم اختيار البريد الإلكتروني	";
$lang['clearlist'] = "لائحة خالية";
$lang['reloading'] = "إعادة";
$lang['seconds'] = "ثواني";


