<?php
$config = array(
"title"=>"TMail - Multi Domain Temporary Email System",
"host"=>"",
"user"=>"",
"pass"=>"",
"domains"=>array(),
"forbidemail"=>array("admin","webmaster","idiot"),
"api"=>"no",
"apikey"=>"",
"admin"=>"tmail123",
);
?>